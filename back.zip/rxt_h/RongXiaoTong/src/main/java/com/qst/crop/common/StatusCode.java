package com.qst.crop.common;

public class StatusCode {
    public static final int OK = 20000;//成功
    public static final int ERROR = 20001;//失败
}
