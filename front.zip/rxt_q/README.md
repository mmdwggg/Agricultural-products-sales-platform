<<<<<<< HEAD
# rongxiaotong

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).
=======
RongXiaoTong-front
>>>>>>> 1d7fc0d52e04ec44b7f60d46183608d39dcb9a74
